1.
There are 42 errors and 90 warnings(CSS3) or 96 errors and 92 warnings(CSS2.1) in screen.css.
All the errors and warnings are caused by border-radius and PIE.htc that are confirmed on forum.